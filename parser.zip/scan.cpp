#include"globals.h"
#include"util.h"
#include"scan.h"



typedef enum//״̬����
{
	//START,INASSIGN,INCOMMENT,INNUM,INID,DONE
	START, INSTARTCOMMENT, INENDCOMMENT, INCOMMENT, INID, INNUM, INBEQ, INAEQ, INEQ, INNEQ, DONE

}StateType;

char tokenString[MAXTOKENLEN + 1];

#define BUFLEN 256//���������256

static char lineBuf[BUFLEN];//������
static int linepos = 0;//�������У���ǰָ����ַ�
static int bufsize = 0;//������װ��ĳ���
static int EOF_flag = FALSE;//�ļ�������־

static int getNextChar(void)//��ȡ��һ���ַ�
{
	if (!(linepos < bufsize))//��ǰ����������
	{
		lineno++;//������һ��
		if (fgets(lineBuf, BUFLEN - 1, source))//�ļ�δ����
		{
			
			bufsize = strlen(lineBuf);
			linepos = 0;
			return lineBuf[linepos++];

		}
		else//�ļ�����
		{
			
			EOF_flag = TRUE;
			return EOF;//�����ļ���������
		}

	}
	else return lineBuf[linepos++];//������δ���꣬�����ַ�
}


static void ungetNextChar(void)//��Ҫ����һ���ַ�
{
	if (!EOF_flag) linepos--;//����ļ�δ����������һ���ַ�
}

static struct//����ؼ��ֱ�
{
	char* str;
	TokenType tok;
}reservedWords[MAXRESERVED] =
{
	{(char*)"if",IF},{(char*)"else",ELSE},{(char*)"int",INT},
	  {(char*)"return",RETURN},{(char*)"void",VOID},{(char*)"while",WHILE}
};

static TokenType reservedLookup(char* s) //����Ƿ��ǹؼ���
{
	int i;
	for (i = 0; i < MAXRESERVED; i++)
	{
		if (!strcmp(s, reservedWords[i].str))//�ǹؼ���
			return reservedWords[i].tok;
	}
	return ID;
}






TokenType getToken(void)
{
	int tokenStringIndex = 0;//���洢�ĵ��ʼǺŵ�λ��

	TokenType currentToken;//�õ��ĵ��ʼǺ�

	StateType state = START;//״̬

	int save = TRUE;//����Ǻ�


	while (state != DONE)
	{

		save = TRUE;
		char c = getNextChar();//�洢��ǰ�ַ�




		switch (state)
		{
		case START:
			if (isdigit(c))
				state = INNUM;
			else if (isalpha(c))
				state = INID;
			else if ((c == ' ') || (c == '\t') || (c == '\n'))
				save = FALSE;
			else if (c == '/')//�����ǳ��ţ�Ҳ������ע�ͷ���
			{
				save = FALSE;
				state = INSTARTCOMMENT;
			}
			else if (c == '<')
			{
				state = INBEQ;
			}
			else if (c == '>')
			{
				state = INAEQ;
			}
			else if (c == '=')
			{
				state = INEQ;
			}
			else if (c == '~')
			{
				state = INNEQ;
			}
			else
			{
				state = DONE;
				switch (c)
				{
				case EOF:
					save = FALSE;
					currentToken = ENDFILE;
					break;
				case '+':
					currentToken = PLUS;
					break;
				case '-':
					currentToken = MINUS;
					break;
				case '*':
					currentToken = TIMES;
					break;
				case ';':
					currentToken = SEMI;
					break;
				case ',':
					currentToken = COMMA;
					break;
				case '(':
					currentToken = LSMALLPAREN;
					break;
				case ')':
					currentToken = RSMALLPAREN;
					break;
				case '[':
					currentToken = LMIDPAREN;
					break;
				case ']':
					currentToken = RMIDPAREN;
					break;
				case '{':
					currentToken = LBIGPAREN;
					break;
				case '}':
					currentToken = RBIGPAREN;
					break;
				default:
					currentToken = ERROR;
					break;
				}//end switch(c)

			}//end ELSE
			break;//END START
		case INSTARTCOMMENT:
			save = FALSE;
			if (c == '*')//˵����ע��
			{
				state = INCOMMENT;
			}
			else//˵���ǳ���
			{
				ungetNextChar();
				state = DONE;
				currentToken = OVER;
				tokenString[tokenStringIndex++] = '/';
			}
			break;
		case INCOMMENT:
			save = FALSE;
			if (c == EOF)//�����ļ���β
			{
				state = DONE;
				currentToken = ENDFILE;
			}
			else if (c == '*')
			{
				state = INENDCOMMENT;
			}
			break;
		case INENDCOMMENT:
			save = FALSE;
			if (c == EOF)//�����ļ���β
			{
				state = DONE;
				currentToken = ENDFILE;
			}
			else if (c == '*')//�Դ���INENDCOMMENT��
			{
				state = INENDCOMMENT;
			}
			else if (c == '/')//��ע��״̬
			{
				state = START;
			}
			else
			{
				state = INCOMMENT;
			}

			break;

		case INBEQ:
			state = DONE;
			if (c == '=')
			{
				currentToken = BEQ;
			}
			else
			{
				ungetNextChar();
				save = FALSE;
				currentToken = BL;
			}
			break;
		case INAEQ:
			state = DONE;
			if (c == '=')
			{
				currentToken = AEQ;
			}
			else
			{
				ungetNextChar();
				save = FALSE;
				currentToken = AB;
			}
			break;
		case INEQ:
			state = DONE;
			if (c == '=')
			{
				currentToken = EQ;
			}
			else
			{
				ungetNextChar();
				save = FALSE;
				currentToken = ASSIGN;
			}
			break;
		case INNEQ:
			state = DONE;
			if (c == '=')
			{
				currentToken = NEQ;
			}
			else
			{
				ungetNextChar();
				save = FALSE;
				currentToken = ERROR;
			}
			break;
			break;
		case INNUM:
			if (!isdigit(c))
			{
				ungetNextChar();
				save = FALSE;
				state = DONE;
				currentToken = NUM;
			}
			break;
		case INID:
			if (!isalpha(c))
			{
				ungetNextChar();
				save = FALSE;
				state = DONE;
				currentToken = ID;
			}
			break;
		case DONE:
		default:
			fprintf(listing, "Scanner Bug: state=%d\n", state);
			state = DONE;
			currentToken = ERROR;
			break;
		}//end switch


		if ((save) && (tokenStringIndex <= MAXTOKENLEN))
		{
			tokenString[tokenStringIndex++] = (char)c;
		}

		if (state == DONE)
		{
			tokenString[tokenStringIndex] = '\0';
			if (currentToken == ID)
			{
				currentToken = reservedLookup(tokenString);
			}
		}

	}//end while

	
	return currentToken;
}

