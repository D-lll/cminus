#include"globals.h"
#include"parse.h"
#include"scan.h"
#include"util.h"
#include<stack>

static TokenType token;
//fprintf(listing, "Debug: %s", tokenString);                                 //DEBUG

static void syntaxError(char* message);
static void match(TokenType expected);
static TreeNode* declaration_list(void);
static TreeNode* declaration(void);
static void type_specifier(void);
static TreeNode* declaration1(void);
static TreeNode* param_list(void);
static TreeNode* compound_stmt(void);
static TreeNode* param_list1(void);
static TreeNode* param_list2(void);
static TreeNode* param(void);
static TreeNode* Var_declaration(void);
static TreeNode* statement(void);
static TreeNode* selection_stmt(void);
static TreeNode* iteration_stmt(void);
static TreeNode* return_stmt(void);
static TreeNode* expression_stmt(void);
static TreeNode* expression(void);
static TreeNode* simple_expression(void);
static TreeNode* additive_expression(void);
static TreeNode* term(void);
static TreeNode* factor(void);
static TreeNode* arg_list(void);

//���ͺ�id������
#define MAXBUFFER 100
static VarType type[MAXBUFFER];
static char storeID[MAXBUFFER][MAXTOKENLEN];
static int typeCount = -1, storeCount=-1;

static TreeNode* declaration_list(void)
{
    memset(storeID, '\0', MAXBUFFER * MAXTOKENLEN);
    TreeNode* t = NULL;
    t = declaration();
    TreeNode* p = t;
    while (token != ENDFILE)
    {
        if (p != NULL)
        {
            TreeNode* s = declaration();
            p->sibling = s;
            p = s;
        }
    }
    return t;
}

static TreeNode* declaration(void)
{
    TreeNode* t = NULL;
    type_specifier();
    if (token == ID)
    {
        memset(storeID[++storeCount], '\0', MAXTOKENLEN);
        strcpy(storeID[storeCount], tokenString);
    }
    match(ID);
    t = declaration1();
    return t;
}

static void type_specifier(void)
{
    switch (token)
    {
    case INT:
        type[++typeCount] = VarType_IntK;
        match(INT);
        break;
    case VOID:
        type[++typeCount] = VarType_VoidK;
        match(VOID);
        break;
    default:
        syntaxError((char*)"unexpected token ->");
        printToken(token, tokenString);
        token = getToken();
        break;
    }
}

static TreeNode* declaration1(void)
{
    TreeNode* t = NULL;
    switch (token)
    {
    case SEMI:
        //��ͨ��������
        t = newVar(type[typeCount--], storeID[storeCount--]);
        match(SEMI);
        break;
    case LMIDPAREN:
        //����
        match(LMIDPAREN);
        if (token == NUM)t = newArray(type[typeCount--], storeID[storeCount--], Arry_DeclK, atoi(tokenString));
        match(NUM);
        match(RMIDPAREN);
        match(SEMI);
        break;
    case LSMALLPAREN:
        //��������
        match(LSMALLPAREN);
        TreeNode* params = NULL;
        TreeNode* compoundStmt = NULL;
        if(token!=RSMALLPAREN) params = param_list();
        match(RSMALLPAREN);
        compoundStmt = compound_stmt();
        t = newFunction(type[typeCount--], storeID[storeCount--], params, compoundStmt);
        break;
    }
    return t;
}

static TreeNode* param_list(void)
{
    TreeNode* t = newParams();
    switch (token)
    {
    case VOID:
        t->child[0] = param_list1();
        break;
    case INT:
        t->child[0] = param_list2();
        break;
    default:
        syntaxError((char*)"unexpected token->");
        printToken(token, tokenString);
        token = getToken();
        break;
    }
    return t;
}


static TreeNode* param_list1(void)
{
    TreeNode* t = NULL;
    match(VOID);
    t = newParam(VarType_VoidK, Arry_NOTARRAY, (char*)"");
    return t;
}

static TreeNode* param_list2(void)
{
    TreeNode* t = NULL;
    match(INT);
    char temp[MAXTOKENLEN];
    memset(temp, '\0', MAXTOKENLEN * sizeof(char));
    if (token == ID)
    {
        strcpy(temp, tokenString);
    }
    match(ID);
    if (token == LMIDPAREN)//������
    {
        match(LMIDPAREN);
        match(RMIDPAREN);
        t = newParam(VarType_IntK, Arry_ElemK, temp);
    }
    else//��������
    {
        t = newParam(VarType_IntK, Arry_NOTARRAY, temp);
    }
    TreeNode* p = t;
    while (token == COMMA)
    {
        match(COMMA);
        TreeNode* s = param();
        p->sibling = s;
        p = s;
    }
    return t;
}

static TreeNode* param(void)
{
    TreeNode* t = NULL;
    type_specifier();
    if (token == ID)
    {
        memset(storeID[++storeCount], '\0', MAXTOKENLEN);
        strcpy(storeID[storeCount], tokenString);
    }
    match(ID);
    if (token == LMIDPAREN)//������
    {
        match(LMIDPAREN);
        match(RMIDPAREN);
        t = newParam(type[typeCount--], Arry_ElemK, storeID[storeCount--]);
    }
    else//��������
    {
        t = newParam(type[typeCount--], Arry_NOTARRAY, storeID[storeCount--]);
    }
    return t;
}


static TreeNode* Var_declaration(void)
{
    TreeNode* t = NULL;
    type_specifier();
    if (token == ID)
    {
        memset(storeID[++storeCount], '\0', MAXTOKENLEN);
        strcpy(storeID[storeCount], tokenString);
    }
    match(ID);
    if (token == LMIDPAREN)//������
    {
        match(LMIDPAREN);
        if (token == NUM)
        {
            t = newArray(type[typeCount--], storeID[storeCount--], Arry_DeclK, atoi(tokenString));
            match(NUM);
            match(RMIDPAREN);
            match(SEMI);
        }
    }

    
    else//��������
    {
        match(SEMI);
        t = newVar(type[typeCount--], storeID[storeCount--]);
    }
    return t;
}



static TreeNode* compound_stmt(void)
{
    TreeNode* t = NULL;
    if (token != SEMI)
    {
        t = newCompound();
        TreeNode* p = NULL;
        match(LBIGPAREN);
        while ((token == VOID) || (token == INT))//����VAR_DECLARATION
        {
            TreeNode* s = Var_declaration();
            if (s != NULL)//�ڴ��㹻
            {
                if (t->child[0] == NULL)//λ��ͷ��
                {
                    t->child[0] = p = s;
                }
                else
                {
                    p->sibling = s;
                    p = s;
                }
            }
            else//�ڴ治��
            {
                syntaxError((char*)"Out of memory");//2
                printToken(token, tokenString);
                token = getToken();
            }
        }
        while ((token != ELSE) && (token != ENDFILE) && (token != RBIGPAREN))
        {
            TreeNode* s = statement();
            
                if (t->child[0] == NULL)//λ��ͷ��
                {
                    t->child[0] = p = s;
                }
                else
                {
                    p->sibling = s;
                    p = s;
                }
        }
        if (token == RBIGPAREN) match(RBIGPAREN);
    }
    else match(SEMI);
    return t;
}


static TreeNode* statement(void)
{
    TreeNode* t = NULL;
    switch (token)
    {
    case LBIGPAREN://compound_stmt
        t = compound_stmt();
        break;
    case IF://select_stmt
        t = selection_stmt();
        break;
    case WHILE://iteration_stmt
        t = iteration_stmt();
        break;
    case RETURN://return_stmt
        t = return_stmt();
        break;

    case SEMI://EXPRESSION_STMT
    case ID:
    case LSMALLPAREN:
    case NUM:
        t = expression_stmt();
        break;
    default:
        syntaxError((char*)"unexpected token->");
        printToken(token, tokenString);
        token = getToken();
        break;
    }
    return t;
}
static TreeNode* selection_stmt(void)
{
    TreeNode* t = newStmt(Stmt_SelectionK);
    match(IF);
    match(LSMALLPAREN);
    if(token!= RSMALLPAREN)t->child[0] = expression();//0�ź��Ӵ������
    match(RSMALLPAREN);
    t->child[1] = statement();//1�ź��Ӵ��then���
    //fprintf(listing, "Debug out of else : %s", tokenString);                                 //DEBUG
    if (token == ELSE)
    {
        //fprintf(listing, "Debug in else : %s", tokenString);                                 //DEBUG
        match(ELSE);
        t->child[2] = statement();//2�ź���ָ��else���
    }
    return t;
}

static TreeNode* iteration_stmt(void)
{
    TreeNode* t = newStmt(Stmt_IterationK);
    match(WHILE);
    match(LSMALLPAREN);
    if(token!= RSMALLPAREN)t->child[0] = expression();//0�ź���ָ�����ʽ
    match(RSMALLPAREN);
    t->child[1] = statement();
    return t;
}

static TreeNode* return_stmt(void)
{
    TreeNode* t = newStmt(Stmt_ReturnK);
    match(RETURN);
     if ((token == ID) || (token == NUM) || (token == LSMALLPAREN))//�з���ֵʱ
    {
        t->child[0] = expression_stmt();//0�ź���ָ�򷵻ر���ʽ
    }
    return t;
}

static TreeNode* expression_stmt(void)
{
    TreeNode* t = NULL;
    if ((token == ID) || (token == NUM) || (token == LSMALLPAREN))
    {
        t = expression();
    }
    match(SEMI);
    return t;
}


//memset(expID, '\0', MAXIDLEN* MAXTOKENLEN * sizeof(char));

static TreeNode* expression(void)
{
    TreeNode* t = simple_expression();
    if (token == ASSIGN)//�Ǹ�ֵ���
    {
        TreeNode* p = newExp(Exp_AssignOpK);
        p->child[0] = t;
        match(ASSIGN);
        p->child[1] = expression();
        t = p;
    }
    return t;
}

static TreeNode* simple_expression(void)
{
    TreeNode* t = additive_expression();
    if ((token == BEQ) || (token == BL) || (token == AB) || (token == AEQ) || (token == EQ) || (token == NEQ))//���жϱ���ʽʱ
    {
        TreeNode* p = newExp(Exp_RelOpK);
        p->child[0] = t;
        p->attr.op = token;
        match(token);
        p->child[1] = additive_expression();
        t = p;
    }
    return t;
}

static TreeNode* additive_expression(void)
{
    TreeNode* t = term();
    while ((token == PLUS) || (token == MINUS))//����һ���ӷ��ڵ�
    {
        TreeNode* p = newExp(Exp_AddOpK);
        p->child[0] = t;
        p->attr.op = token;
        match(token);
        p->child[1] = term();
        t = p;
    }
    return t;
}

static TreeNode* term(void)
{
    TreeNode* t = factor();
    while ((token == TIMES) || (token == OVER))//��һ���˷��ڵ�
    {
        TreeNode* p = newExp(Exp_MulOpK);
        p->child[0] = t;
        p->attr.op = token;
        match(token);
        p->child[1] = factor();
        t = p;
    }
    return t;
}
static TreeNode* factor(void)
{
    TreeNode* t = NULL;
    switch (token)
    {
    case ID:
        char tempName[MAXTOKENLEN];
        memset(tempName, '\0', MAXTOKENLEN * sizeof(char));
        strcpy(tempName, tokenString);
        match(ID);
        if (token == LSMALLPAREN)//��������
        {
            match(LSMALLPAREN);
            //�½�һ�������ڵ�
            t = newCall(tempName);
            t->child[0] = arg_list();//0�Žڵ�ָ������б�
            match(RSMALLPAREN);
        }
        else //var����
        {
            if (token == LMIDPAREN)//��������
            {
                match(LMIDPAREN);
                t = newExp(Exp_ArrayK);
                t->arry = Arry_ElemK;
                if (token == NUM)//�������±�
                {
                    t->arry = Array_const;
                    t->attr.Const = atoi(tokenString);
                    match(NUM);
                }
                else if (token == ID)//�������±�
                {
                    t->arry = Array_var;
                    t->attr.varIndex = (char*)malloc(MAXTOKENLEN);
                    memset(t->attr.varIndex, '\0', MAXTOKENLEN);
                    strcpy(t->attr.varIndex, tokenString);
                    match(ID);
                }
                strcpy(t->attr.id, tempName);
                match(RMIDPAREN);
            }
            else//��ͨvar
            {
                t = newExp(Exp_VarK);
                strcpy(t->attr.id, tempName);
            }
        }
        break;
    case LSMALLPAREN:
        match(LSMALLPAREN);
        t = expression();
        match(RSMALLPAREN);
        break;
    case NUM:
        t = newExp(Exp_KeyK);
        t->attr.Const = atoi(tokenString);
        match(NUM);
        break;
    default:
        syntaxError((char*)"unexpected token->");
        printToken(token, tokenString);
        token = getToken();
        break;
    }
    return t;
}

static TreeNode* arg_list(void)
{
    TreeNode* t = NULL;
    if (token == RSMALLPAREN)//�ղ���
    {
       // t = newArg();
    }
    else
    {
        t = newArg();
        t->child[0] = expression();
        TreeNode* p = t->child[0];
        while (token == COMMA)
        {
            match(COMMA);
            TreeNode* s = expression();
            p->sibling = s;
            p = s;
        }
    }
    return t;
}



static void syntaxError(char* message)
{
    fprintf(listing, "\n>>> ");
    fprintf(listing, "  Syntax error at line %d: %s", lineno, message);
    Error = TRUE;
}

static void match(TokenType expected)
{
    if (token == expected) token = getToken();
    else {
        syntaxError((char*)"unexpected token -> ");
        printToken(token, tokenString);
        fprintf(listing, "      ");
    }
}


TreeNode* parse(void)
{
    TreeNode* t;
    token = getToken();
    t = declaration_list();
    if (token != ENDFILE)
        syntaxError((char*)"Code ends before file\n");
    return t;
}

