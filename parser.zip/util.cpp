#include "globals.h"
#include "util.h"
#include"scan.h"
#include"parse.h"
void printToken(TokenType token, const char* tokenString)
{

	switch (token)
	{
	case IF:
	case ELSE:
	case INT:
	case RETURN:
	case VOID:
	case WHILE:
		//�ؼ���
		fprintf(listing, "reserved word: %s\n", tokenString);
		break;
		//��ֵ�Ǻ�
	case PLUS:fprintf(listing, "+\n"); break;//
	case MINUS:fprintf(listing, "-\n"); break;//
	case TIMES:fprintf(listing, "*\n"); break;//
	case OVER:fprintf(listing, "/\n"); break;//
	case BL:fprintf(listing, "<\n"); break;//
	case BEQ:fprintf(listing, "<=\n"); break;//
	case AB:fprintf(listing, ">\n"); break;//
	case AEQ:fprintf(listing, ">=\n"); break;//
	case EQ:fprintf(listing, "==\n"); break;//
	case NEQ:fprintf(listing, "~=\n"); break;//
	case ASSIGN: fprintf(listing, "=\n"); break;//
	case SEMI:fprintf(listing, ";\n"); break;//
	case COMMA:fprintf(listing, ",\n"); break;//
	case LSMALLPAREN:fprintf(listing, "(\n"); break;//
	case RSMALLPAREN:fprintf(listing, ")\n"); break;//
	case LMIDPAREN:fprintf(listing, "[\n"); break;//
	case RMIDPAREN:fprintf(listing, "]\n"); break;//
	case LBIGPAREN:fprintf(listing, "{\n"); break;//
	case RBIGPAREN:fprintf(listing, "}\n"); break;//
	//case ENDFILE:fprintf(listing, "EOF\n"); break;

	//��ָ�Ǻ�
	case NUM:fprintf(listing, "NUM, val= %s\n", tokenString); break;
	case ID:fprintf(listing, "ID, name= %s\n", tokenString); break;

	case ERROR:fprintf(listing, "ERROR : %s\n", tokenString); break;


	default:fprintf(listing, "Unknown token: %d\n", token);

	}
}



TreeNode* newVar(VarType type, char* id)//�½�һ�������ڵ�
{
	TreeNode* t = (TreeNode*)malloc(sizeof(TreeNode));
	t->kind = VarK;
	t->varType = type;
	t->attr.id = (char*)malloc(sizeof(char) * MAXTOKENLEN);
	memset(t->attr.id, '\0', MAXTOKENLEN * sizeof(char));
	strcpy(t->attr.id, id);
	for (int i = 0; i < MAXCHILDREN; i++)
	{
		t->child[i] = NULL;
	}
	t->sibling = NULL;
	return t;
}


TreeNode* newArray(VarType type, char* id, Array array, int num)//�½�һ������ڵ�
{
	TreeNode* t = (TreeNode*)malloc(sizeof(TreeNode));
	t->kind = VarArrayK;
	t->varType = type;
	t->arry = array;
	t->attr.id = (char*)malloc(sizeof(char) * MAXTOKENLEN);
	memset(t->attr.id, '\0', MAXTOKENLEN * sizeof(char));
	strcpy(t->attr.id, id);
	t->attr.Const = num;
	for (int i = 0; i < MAXCHILDREN; i++)
	{
		t->child[i] = NULL;
	}
	t->sibling = NULL;
	return t;
}

TreeNode* newFunction(VarType type, char* id, TreeNode* params, TreeNode* compoundStmt)//�½�һ�����������ڵ�
{
	TreeNode* t = (TreeNode*)malloc(sizeof(TreeNode));
	t->kind = FuncK;
	t->varType = type;
	t->attr.id = (char*)malloc(sizeof(char) * MAXTOKENLEN);
	memset(t->attr.id, '\0', MAXTOKENLEN * sizeof(char));
	strcpy(t->attr.id, id);
	for (int i = 0; i < MAXCHILDREN; i++)
	{
		t->child[i] = NULL;
	}
	t->child[0] = params;
	t->child[1] = compoundStmt;
	t->sibling = NULL;
	return t;
}

TreeNode* newParams()//�½�һ��������ڵ�
{
	TreeNode* t = (TreeNode*)malloc(sizeof(TreeNode));
	t->kind = ParamsK;
	for (int i = 0; i < MAXCHILDREN; i++)
	{
		t->child[i] = NULL;
	}
	t->sibling = NULL;
	return t;
}
TreeNode* newParam(VarType type, Array array, char* id)//�½�һ�������ڵ�,�����Ƿ���������array�и���
{
	TreeNode* t = (TreeNode*)malloc(sizeof(TreeNode));
	t->kind = ParamK;
	t->varType = type;
	t->arry = array;
	t->attr.id = (char*)malloc(sizeof(char) * MAXTOKENLEN);
	memset(t->attr.id, '\0', MAXTOKENLEN * sizeof(char));
	strcpy(t->attr.id, id);
	for (int i = 0; i < MAXCHILDREN; i++)
	{
		t->child[i] = NULL;
	}
	t->sibling = NULL;
	return t;
}

TreeNode* newCompound()//�½�һ��������ڵ�
{
	TreeNode* t = (TreeNode*)malloc(sizeof(TreeNode));
	t->kind = CompK;
	for (int i = 0; i < MAXCHILDREN; i++)
	{
		t->child[i] = NULL;
	}
	t->sibling = NULL;
	return t;
}

TreeNode* newStmt(Stmt stmt)//�½�һ����������ڵ�
{
	TreeNode* t = (TreeNode*)malloc(sizeof(TreeNode));
	t->kind = StmtK;
	t->stmt = stmt;
	t->attr.id = (char*)malloc(sizeof(char) * MAXTOKENLEN);
	memset(t->attr.id, '\0', MAXTOKENLEN * sizeof(char));
	for (int i = 0; i < MAXCHILDREN; i++)
	{
		t->child[i] = NULL;
	}
	t->sibling = NULL;
	return t;
}

TreeNode* newExp(Exp exp)//�½�һ������ڵ�
{
	TreeNode* t = (TreeNode*)malloc(sizeof(TreeNode));
	t->kind = ExpK;
	t->exp = exp;
	t->attr.id = (char*)malloc(sizeof(char) * MAXTOKENLEN);
	memset(t->attr.id, '\0', MAXTOKENLEN * sizeof(char));
	for (int i = 0; i < MAXCHILDREN; i++)
	{
		t->child[i] = NULL;
	}
	t->sibling = NULL;
	return t;
}

TreeNode* newCall(char* id)//�½�һ�����ò����ڵ�
{
	TreeNode* t = (TreeNode*)malloc(sizeof(TreeNode));
	t->kind = CallK;
	t->attr.id = (char*)malloc(sizeof(char) * MAXTOKENLEN);
	memset(t->attr.id,'\0',MAXTOKENLEN*sizeof(char));
	strcpy(t->attr.id, id);
	for (int i = 0; i < MAXCHILDREN; i++)
	{
		t->child[i] = NULL;
	}
	t->sibling = NULL;
	return t;
}


TreeNode* newArg()//�½�һ�����ò����ڵ�
{
	TreeNode* t = (TreeNode*)malloc(sizeof(TreeNode));
	t->kind = ArgK;
	t->attr.id = (char*)malloc(sizeof(char) * MAXTOKENLEN);
	memset(t->attr.id, '\0', MAXTOKENLEN * sizeof(char));
	for (int i = 0; i < MAXCHILDREN; i++)
	{
		t->child[i] = NULL;
	}
	t->sibling = NULL;
	return t;
}

static int indentno = 0;

/* macros to increase/decrease indentation */
#define INDENT indentno+=2
#define UNINDENT indentno-=2

static void printSpaces(void)
{
	int i;
	for (i = 0; i < indentno; i++)
		fprintf(listing, " ");
}
static void printNSpaces(int n)
{
	printSpaces();
	while((n--)>0) fprintf(listing, " ");
}
void printTree(TreeNode* tree)
{
	int i;
	INDENT;
	while (tree != NULL)
	{
		printSpaces();
		if (tree->kind == VarK)//�Ǳ������
		{
			switch (tree->varType)
			{
			case VarType_IntK:
				fprintf(listing, "Var_DeclK\n");

				printNSpaces(2);
				fprintf(listing, "IntK\n");

				printNSpaces(2);
				fprintf(listing, "IdK: %s\n",tree->attr.id);
				break;
			default:
				//�����������
				break;
			}
		}//end if
		else if (tree->kind == VarArrayK)//�Ǳ���������
		{
			if (tree->arry == Arry_DeclK)//������������
			{
				fprintf(listing, "Var_DeclK\n");

				printNSpaces(2);
				fprintf(listing, "IntK\n");

				printNSpaces(2); 
				fprintf(listing, "Arry_DeclK\n");

				printNSpaces(4); 
				fprintf(listing, "IdK: %s\n",tree->attr.id);

				printNSpaces(4);
				fprintf(listing, "ConstK: %d\n", tree->attr.Const);
			}
			else if (tree->arry == Arry_ElemK)//����Ԫ������
			{

			}
		}
		else if (tree->kind == FuncK)//�Ǻ��������ڵ�
		{
			fprintf(listing, "FuncK\n");

			if (tree->varType == VarType_IntK)
			{
				printNSpaces(2);
				fprintf(listing, "IntK\n");//��ӡ��������

				printNSpaces(2);
				fprintf(listing, "IdK: %s\n",tree->attr.id);//��ӡ������
			}
			else if (tree->varType == VarType_VoidK)
			{
				printNSpaces(2);
				fprintf(listing, "VoidK\n");//��ӡ��������

				printNSpaces(2);
				fprintf(listing, "IdK: %s\n", tree->attr.id);//��ӡ������
			}
			else
			{
				//��������������
			}

		}
		else if (tree->kind == ParamsK)//�Ǻ���������ڵ�
		{
			fprintf(listing, "ParamsK\n");
		}
		else if (tree->kind == ParamK)//�Ǻ��������ڵ�
		{

			if (tree->varType==VarType_IntK)//���Ͳ���
			{
				if (tree->arry == Arry_NOTARRAY)//��������
				{
					fprintf(listing, "ParamK\n");

					printNSpaces(2);
					fprintf(listing, "IntK\n");//��ӡ��������

					printNSpaces(2);
					fprintf(listing, "IdK: %s\n", tree->attr.id);//��ӡ����
				}
				else//������
				{
					fprintf(listing, "ParamK\n");

					printNSpaces(2);
					fprintf(listing, "IntK\n");//��ӡ��������

					printNSpaces(2);
					fprintf(listing, "IdK: %s\n", tree->attr.id);//��ӡ����

					printNSpaces(2);
					fprintf(listing, "IdK: \n");//��ӡ����
				}
				
			}
			else if (tree->varType == VarType_VoidK)//�޲���
			{
				fprintf(listing, "VoidK\n");//��ӡ��������
			}
			else//���󷵻�����
			{

			}

		}

		else if (tree->kind == CompK)//�Ǻ��������ڵ�
		{
			fprintf(listing, "CompK\n");
		}

		else if (tree->kind == StmtK)//�Ǻ������ڵ�
		{

			if (tree->stmt == Stmt_ReturnK)//�Ƿ������
			{
				fprintf(listing, "Return\n");
			}
			else if (tree->stmt == Stmt_IterationK)//��ѭ������
			{
				fprintf(listing, "While\n");
			}
			else if (tree->stmt == Stmt_SelectionK)//ѡ������
			{
				fprintf(listing, "If\n");
			}
			else//������������
			{

			}
		}

//typedef enum { , , , , , Exp_ExpK, Exp_ArrayK,  }Exp;
		else if (tree->kind == ExpK)//�Ǳ���ʽ�ڵ�
		{
			switch (tree->exp)
			{
			case Exp_AssignOpK://��ֵ�ͱ���ʽ
				fprintf(listing, "Assign\n");
				break;
			case Exp_AddOpK:
			case Exp_MulOpK:
			case Exp_RelOpK:
				fprintf(listing, "Op: ");
					switch (tree->attr.op)
					{
					case PLUS:fprintf(listing, "+\n"); break;//
					case MINUS:fprintf(listing, "-\n"); break;//
					case TIMES:fprintf(listing, "*\n"); break;//
					case OVER:fprintf(listing, "/\n"); break;//
					case BL:fprintf(listing, "<\n"); break;//
					case BEQ:fprintf(listing, "<=\n"); break;//
					case AB:fprintf(listing, ">\n"); break;//
					case AEQ:fprintf(listing, ">=\n"); break;//
					case EQ:fprintf(listing, "==\n"); break;//
					case NEQ:fprintf(listing, "~=\n"); break;//
					default:
						//�������������
						break;
					}
				break;
			case Exp_KeyK://��ֵ����
				fprintf(listing, "ConstK: %d\n",tree->attr.Const);
				break;
			case Exp_VarK://��������
				fprintf(listing, "IdK: %s\n", tree->attr.id);
				break;
			case Exp_ArrayK://��������
				fprintf(listing, "Arry_ElemK\n");
				if (tree->arry == Array_const)//����������
				{
					printNSpaces(2);
					fprintf(listing, "IdK: %s\n", tree->attr.id);

					printNSpaces(2);
					fprintf(listing, "ConstK: %d\n", tree->attr.Const);
				}
				else if (tree->arry == Array_var)//����������
				{
					printNSpaces(2);
					fprintf(listing, "IdK: %s\n", tree->attr.id);

					printNSpaces(2);
					fprintf(listing, "IdK: %s\n", tree->attr.varIndex);
				}
				else
				{
					//�����±����ʹ���
				}
				break;
			default:
				break;
			}
		}
		else if (tree->kind == CallK)//�Ǻ������ýڵ�
		{
			fprintf(listing, "CallK\n");

			printNSpaces(2);
			fprintf(listing, "IdK: %s\n", tree->attr.id);
		}
		else if (tree->kind == ArgK)//�ǵ��ò����ڵ�
		{
			fprintf(listing, "ArgsK\n");
		}
		else fprintf(listing, "Unknown node kind\n");
		for (i = 0; i < MAXCHILDREN; i++)
			printTree(tree->child[i]);
		tree = tree->sibling;
	}//end while
	UNINDENT;
}



